# Ficha de Treino

App de ficha de treino (HTML/JS puro, sem build) empacotado com [Capacitor](https://capacitorjs.com).
Funciona 100% offline. Os dados (ficha editada, séries, histórico) ficam salvos no aparelho.

## Estrutura

- `www/` o app (index.html, manifest, ícones PWA)
- `assets/` ícone e splash (gerados a partir do seu ícone) usados pelo `@capacitor/assets`
- `capacitor.config.json` ID do app (`com.fichatreino.app`) e nome

## Requisitos

- Node.js 20 ou mais novo
- Android: Android Studio (com SDK). iOS: Mac com Xcode e CocoaPods

## Android (APK)

```bash
npm install
npm run add:android      # cria a pasta android/
npm run assets           # gera os ícones e splash a partir de assets/
npm run android          # sincroniza e abre o Android Studio
```

No Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
O APK fica em `android/app/build/outputs/apk/debug/`. Para instalar no celular, ative a depuração USB e use o botão Run.

## Android sem instalar nada (GitHub Actions)

1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclusive `.github/`).
2. Abra a aba **Actions**, escolha **Build APK** e clique em **Run workflow** (também roda a cada push).
3. Ao terminar (uns 5 a 10 minutos), abra a execução e baixe **ficha-treino-apk** em Artifacts. Dentro do zip está o `app-debug.apk`.
4. Envie o APK para o celular e instale (permita "instalar apps de fontes desconhecidas").

## iOS

```bash
npm install
npm run add:ios
npm run assets
npm run ios              # abre o Xcode
```

No Xcode, escolha seu Team em Signing & Capabilities e rode no aparelho.

## Sem compilar: instalar como PWA

Hospede a pasta `www/` em qualquer site estático (GitHub Pages, Netlify, Vercel), abra no celular e use
**Adicionar à tela inicial**. O ícone já está configurado.

## Notas

- Os vídeos abrem no navegador interno do sistema (plugin `@capacitor/browser`): um toque em **OK/Fechar** volta ao app.
- O guia de exercícios é offline. Para exercícios que você criar, escreva o seu "Como fazer" na aba **Editar**.
- Se alterar `www/index.html`, rode `npx cap sync` antes de recompilar.
